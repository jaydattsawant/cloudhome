<?php
require_once 'config/functions.php';
requireAdmin();

$pdo = getDBConnection();

// Handle admin actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    switch ($action) {
        case 'update_storage':
            $user_id = (int)$_POST['user_id'];
            $storage_limit = (int)$_POST['storage_limit'] * 1024 * 1024 * 1024; // Convert GB to bytes

            $stmt = $pdo->prepare("UPDATE users SET storage_limit = ? WHERE id = ?");
            if ($stmt->execute([$storage_limit, $user_id])) {
                $success = "Storage limit updated successfully";
            } else {
                $error = "Failed to update storage limit";
            }
            break;

        case 'toggle_status':
            $user_id = (int)$_POST['user_id'];
            $new_status = $_POST['status'] === 'active' ? 'inactive' : 'active';

            $stmt = $pdo->prepare("UPDATE users SET status = ? WHERE id = ?");
            if ($stmt->execute([$new_status, $user_id])) {
                $success = "User status updated successfully";
            } else {
                $error = "Failed to update user status";
            }
            break;

        case 'promote_user':
            $user_id = (int)$_POST['user_id'];
            $new_role = $_POST['role'] === 'admin' ? 'user' : 'admin';

            $stmt = $pdo->prepare("UPDATE users SET role = ? WHERE id = ? AND id != ?");
            if ($stmt->execute([$new_role, $user_id, $_SESSION['user_id']])) {
                $success = "User role updated successfully";
            } else {
                $error = "Failed to update user role";
            }
            break;
    }
}

// Get statistics
$stats = [];

// Total users
$stmt = $pdo->query("SELECT COUNT(*) FROM users");
$stats['total_users'] = $stmt->fetchColumn();

// Active users
$stmt = $pdo->query("SELECT COUNT(*) FROM users WHERE status = 'active'");
$stats['active_users'] = $stmt->fetchColumn();

// Total files
$stmt = $pdo->query("SELECT COUNT(*) FROM files");
$stats['total_files'] = $stmt->fetchColumn();

// Total storage used
$stmt = $pdo->query("SELECT SUM(file_size) FROM files");
$stats['total_storage'] = $stmt->fetchColumn() ?: 0;

// Recent uploads (last 7 days)
$stmt = $pdo->query("SELECT COUNT(*) FROM files WHERE upload_date >= DATE_SUB(NOW(), INTERVAL 7 DAY)");
$stats['recent_uploads'] = $stmt->fetchColumn();

// Get all users
$stmt = $pdo->query("SELECT *, (SELECT COUNT(*) FROM files WHERE user_id = users.id) as file_count FROM users ORDER BY created_at DESC");
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get recent activity
$stmt = $pdo->prepare("
    SELECT al.*, u.username 
    FROM activity_logs al 
    JOIN users u ON al.user_id = u.id 
    ORDER BY al.created_at DESC 
    LIMIT 20
");
$stmt->execute();
$recent_activity = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CloudStore - Admin Panel</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div class="header">
        <div class="logo">
            <i class="fas fa-cloud"></i>
            <span>CloudStore Admin</span>
        </div>

        <nav>
            <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="admin_panel.php" class="active">Admin Panel</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>

        <div class="user-info">
            <div class="user-avatar"><?= strtoupper(substr($_SESSION['username'], 0, 1)) ?></div>
            <span><?= htmlspecialchars($_SESSION['username']) ?></span>
            <span class="badge" style="background: #ef4444; color: white; padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.75rem;">ADMIN</span>
        </div>
    </div>

    <div class="main-content">
        <?php if (isset($success)): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?= $success ?>
            </div>
        <?php endif; ?>

        <?php if (isset($error)): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i> <?= $error ?>
            </div>
        <?php endif; ?>

        <!-- Statistics -->
        <h2>System Overview</h2>
        <div class="admin-stats">
            <div class="stat-card">
                <span class="stat-number"><?= number_format($stats['total_users']) ?></span>
                <span class="stat-label">Total Users</span>
            </div>
            <div class="stat-card">
                <span class="stat-number"><?= number_format($stats['active_users']) ?></span>
                <span class="stat-label">Active Users</span>
            </div>
            <div class="stat-card">
                <span class="stat-number"><?= number_format($stats['total_files']) ?></span>
                <span class="stat-label">Total Files</span>
            </div>
            <div class="stat-card">
                <span class="stat-number"><?= formatFileSize($stats['total_storage']) ?></span>
                <span class="stat-label">Storage Used</span>
            </div>
            <div class="stat-card">
                <span class="stat-number"><?= number_format($stats['recent_uploads']) ?></span>
                <span class="stat-label">Recent Uploads (7 days)</span>
            </div>
        </div>

        <!-- User Management -->
        <div class="card">
            <h2>User Management</h2>
            <div style="overflow-x: auto;">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Status</th>
                            <th>Files</th>
                            <th>Storage Used</th>
                            <th>Storage Limit</th>
                            <th>Last Login</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user): ?>
                            <tr>
                                <td><?= $user['id'] ?></td>
                                <td><?= htmlspecialchars($user['username']) ?></td>
                                <td><?= htmlspecialchars($user['email']) ?></td>
                                <td>
                                    <span class="badge" style="background: <?= $user['role'] === 'admin' ? '#ef4444' : '#6b7280' ?>; color: white; padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.75rem;">
                                        <?= strtoupper($user['role']) ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="badge" style="background: <?= $user['status'] === 'active' ? '#10b981' : '#ef4444' ?>; color: white; padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.75rem;">
                                        <?= strtoupper($user['status']) ?>
                                    </span>
                                </td>
                                <td><?= $user['file_count'] ?></td>
                                <td><?= formatFileSize($user['storage_used']) ?></td>
                                <td><?= formatFileSize($user['storage_limit']) ?></td>
                                <td><?= $user['last_login'] ? date('M j, Y H:i', strtotime($user['last_login'])) : 'Never' ?></td>
                                <td>
                                    <div style="display: flex; gap: 0.5rem;">
                                        <button onclick="editStorage(<?= $user['id'] ?>, '<?= htmlspecialchars($user['username']) ?>', <?= $user['storage_limit'] / (1024*1024*1024) ?>)" 
                                                class="btn" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;" title="Edit Storage">
                                            <i class="fas fa-hdd"></i>
                                        </button>

                                        <?php if ($user['id'] !== $_SESSION['user_id']): ?>
                                            <form method="POST" style="display: inline;" onsubmit="return confirm('Toggle user status?')">
                                                <input type="hidden" name="action" value="toggle_status">
                                                <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                                <input type="hidden" name="status" value="<?= $user['status'] ?>">
                                                <button type="submit" class="btn" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;" 
                                                        title="<?= $user['status'] === 'active' ? 'Deactivate' : 'Activate' ?> User">
                                                    <i class="fas fa-<?= $user['status'] === 'active' ? 'user-times' : 'user-check' ?>"></i>
                                                </button>
                                            </form>

                                            <form method="POST" style="display: inline;" onsubmit="return confirm('Change user role?')">
                                                <input type="hidden" name="action" value="promote_user">
                                                <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                                <input type="hidden" name="role" value="<?= $user['role'] ?>">
                                                <button type="submit" class="btn" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;" 
                                                        title="<?= $user['role'] === 'admin' ? 'Remove' : 'Make' ?> Admin">
                                                    <i class="fas fa-<?= $user['role'] === 'admin' ? 'user-minus' : 'user-shield' ?>"></i>
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Recent Activity -->
        <div class="card">
            <h2>Recent Activity</h2>
            <div class="file-list">
                <?php foreach ($recent_activity as $activity): ?>
                    <div class="file-item">
                        <div class="file-icon">
                            <?php
                            switch ($activity['action']) {
                                case 'upload': echo '⬆️'; break;
                                case 'download': echo '⬇️'; break;
                                case 'delete': echo '🗑️'; break;
                                case 'share': echo '🔗'; break;
                                case 'login': echo '🔐'; break;
                                case 'create_folder': echo '📁'; break;
                                default: echo '📝';
                            }
                            ?>
                        </div>
                        <div class="file-info">
                            <h4><?= ucfirst($activity['action']) ?></h4>
                            <div class="file-meta">
                                By <?= htmlspecialchars($activity['username']) ?>
                                <?php if ($activity['file_name']): ?>
                                    • <?= htmlspecialchars($activity['file_name']) ?>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="file-date"><?= date('M j, H:i', strtotime($activity['created_at'])) ?></div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- Storage Edit Modal -->
    <div id="storageModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Edit Storage Limit</h2>
                <span class="close" onclick="closeModal('storageModal')">&times;</span>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="update_storage">
                <input type="hidden" id="edit_user_id" name="user_id">
                <div class="form-group">
                    <label for="username_display">User</label>
                    <input type="text" id="username_display" class="form-control" readonly>
                </div>
                <div class="form-group">
                    <label for="storage_limit">Storage Limit (GB)</label>
                    <input type="number" id="storage_limit" name="storage_limit" class="form-control" min="1" max="1000" required>
                    <small style="color: #6b7280;">Enter storage limit in gigabytes (1-1000 GB)</small>
                </div>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> Update Storage Limit
                </button>
            </form>
        </div>
    </div>

    <script>
        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        function editStorage(userId, username, currentLimit) {
            document.getElementById('edit_user_id').value = userId;
            document.getElementById('username_display').value = username;
            document.getElementById('storage_limit').value = currentLimit;
            document.getElementById('storageModal').style.display = 'block';
        }

        // Close modals when clicking outside
        window.onclick = function(event) {
            const modals = document.getElementsByClassName('modal');
            for (let i = 0; i < modals.length; i++) {
                if (event.target === modals[i]) {
                    modals[i].style.display = 'none';
                }
            }
        }
    </script>
</body>
</html>