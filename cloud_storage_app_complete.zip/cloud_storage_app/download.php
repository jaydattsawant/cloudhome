<?php
require_once 'config/functions.php';

$file_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$is_preview = isset($_GET['preview']);
$is_info = isset($_GET['info']);

if (!$file_id) {
    http_response_code(400);
    die('File ID required');
}

$pdo = getDBConnection();

// Get file info
$stmt = $pdo->prepare("SELECT * FROM files WHERE id = ?");
$stmt->execute([$file_id]);
$file = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$file) {
    http_response_code(404);
    die('File not found');
}

// Check if user has access to file
$has_access = false;

if (isLoggedIn()) {
    // User can access their own files or admin can access all files
    if ($_SESSION['user_id'] == $file['user_id'] || isAdmin()) {
        $has_access = true;
    }
}

// Check if file is shared publicly
if (!$has_access) {
    $stmt = $pdo->prepare("SELECT * FROM file_shares WHERE file_id = ?");
    $stmt->execute([$file_id]);
    if ($stmt->fetch()) {
        $has_access = true;
    }
}

if (!$has_access) {
    http_response_code(403);
    die('Access denied');
}

// Return file info as JSON
if ($is_info) {
    header('Content-Type: application/json');
    echo json_encode([
        'name' => $file['original_name'],
        'size' => $file['file_size'],
        'mime_type' => $file['mime_type'],
        'extension' => $file['file_extension']
    ]);
    exit;
}

$file_path = UPLOAD_DIR . $file['user_id'] . '/' . $file['stored_name'];

if (!file_exists($file_path)) {
    http_response_code(404);
    die('File not found on disk');
}

// Update download count (only for actual downloads, not previews)
if (!$is_preview) {
    $stmt = $pdo->prepare("UPDATE files SET downloads = downloads + 1 WHERE id = ?");
    $stmt->execute([$file_id]);

    if (isLoggedIn()) {
        logActivity($_SESSION['user_id'], 'download', $file['original_name']);
    }
}

// Set headers for download
if ($is_preview) {
    header('Content-Type: ' . $file['mime_type']);
} else {
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . $file['original_name'] . '"');
}

header('Content-Length: ' . filesize($file_path));
header('Cache-Control: private, must-revalidate');
header('Pragma: private');
header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');

// Output file
readfile($file_path);
?>