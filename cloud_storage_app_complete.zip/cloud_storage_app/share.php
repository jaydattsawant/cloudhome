<?php
require_once 'config/functions.php';

// Handle sharing actions
if (isset($_GET['action']) && $_GET['action'] === 'create' && isLoggedIn()) {
    header('Content-Type: application/json');

    $file_id = (int)($_GET['file_id'] ?? 0);
    $user_id = $_SESSION['user_id'];

    if (!$file_id) {
        echo json_encode(['success' => false, 'message' => 'File ID required']);
        exit;
    }

    $pdo = getDBConnection();

    // Verify file ownership
    $stmt = $pdo->prepare("SELECT id, original_name FROM files WHERE id = ? AND user_id = ?");
    $stmt->execute([$file_id, $user_id]);
    $file = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$file) {
        echo json_encode(['success' => false, 'message' => 'File not found or access denied']);
        exit;
    }

    // Check if share already exists
    $stmt = $pdo->prepare("SELECT share_token FROM file_shares WHERE file_id = ? AND created_by = ?");
    $stmt->execute([$file_id, $user_id]);
    $existing = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($existing) {
        echo json_encode(['success' => true, 'token' => $existing['share_token']]);
        exit;
    }

    // Create new share
    $token = generateToken();

    try {
        $stmt = $pdo->prepare("INSERT INTO file_shares (file_id, share_token, created_by) VALUES (?, ?, ?)");
        $stmt->execute([$file_id, $token, $user_id]);

        // Update file as shared
        $stmt = $pdo->prepare("UPDATE files SET is_shared = TRUE, share_token = ? WHERE id = ?");
        $stmt->execute([$token, $file_id]);

        logActivity($user_id, 'share', $file['original_name']);

        echo json_encode(['success' => true, 'token' => $token]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Failed to create share link']);
    }
    exit;
}

// Handle shared file download
if (isset($_GET['token'])) {
    $token = $_GET['token'];

    $pdo = getDBConnection();
    $stmt = $pdo->prepare("
        SELECT f.*, fs.download_count, fs.max_downloads 
        FROM files f 
        JOIN file_shares fs ON f.id = fs.file_id 
        WHERE fs.share_token = ?
    ");
    $stmt->execute([$token]);
    $file = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$file) {
        http_response_code(404);
        die('Shared file not found or link has expired');
    }

    // Check download limits
    if ($file['max_downloads'] && $file['download_count'] >= $file['max_downloads']) {
        die('Download limit reached for this shared file');
    }

    // Show download page
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>CloudStore - Shared File</title>
        <link rel="stylesheet" href="assets/css/style.css">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    </head>
    <body>
        <div class="auth-container">
            <div class="auth-card" style="max-width: 500px;">
                <div class="logo" style="justify-content: center; margin-bottom: 2rem;">
                    <i class="fas fa-cloud"></i>
                    <span>CloudStore</span>
                </div>

                <h1 class="auth-title">Shared File</h1>

                <div style="text-align: center; margin: 2rem 0;">
                    <div class="file-icon" style="font-size: 4rem; margin-bottom: 1rem;">
                        <?= getFileIcon($file['file_extension']) ?>
                    </div>
                    <h3><?= htmlspecialchars($file['original_name']) ?></h3>
                    <p style="color: #6b7280;">
                        Size: <?= formatFileSize($file['file_size']) ?> • 
                        Type: <?= strtoupper($file['file_extension']) ?>
                    </p>
                    <p style="color: #6b7280; font-size: 0.875rem;">
                        Downloads: <?= $file['downloads'] ?>
                        <?php if ($file['max_downloads']): ?>
                            / <?= $file['max_downloads'] ?>
                        <?php endif; ?>
                    </p>
                </div>

                <?php if (canPreviewFile($file['file_extension'])): ?>
                    <div style="margin: 2rem 0;">
                        <?php if (in_array($file['file_extension'], ['jpg', 'jpeg', 'png', 'gif', 'webp'])): ?>
                            <img src="download.php?id=<?= $file['id'] ?>&preview=1" 
                                 alt="Preview" style="max-width: 100%; border-radius: 8px;">
                        <?php elseif (in_array($file['file_extension'], ['mp4', 'webm', 'ogg'])): ?>
                            <video controls style="max-width: 100%; border-radius: 8px;">
                                <source src="download.php?id=<?= $file['id'] ?>&preview=1" type="<?= $file['mime_type'] ?>">
                            </video>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <a href="download.php?id=<?= $file['id'] ?>" class="btn btn-primary" style="width: 100%; text-align: center; text-decoration: none;">
                    <i class="fas fa-download"></i> Download File
                </a>

                <div style="text-align: center; margin-top: 2rem; padding-top: 2rem; border-top: 1px solid #e5e7eb;">
                    <p style="color: #6b7280; font-size: 0.875rem;">
                        This file was shared with you via CloudStore
                    </p>
                    <a href="index.php" style="color: #4f46e5; text-decoration: none; font-size: 0.875rem;">
                        Create your own free account
                    </a>
                </div>
            </div>
        </div>
    </body>
    </html>
    <?php
    exit;
}

// Show user's shared files (requires login)
requireLogin();

$user_id = $_SESSION['user_id'];
$pdo = getDBConnection();

// Get user's shared files
$stmt = $pdo->prepare("
    SELECT f.*, fs.share_token, fs.download_count, fs.created_at as shared_at
    FROM files f 
    JOIN file_shares fs ON f.id = fs.file_id 
    WHERE f.user_id = ? 
    ORDER BY fs.created_at DESC
");
$stmt->execute([$user_id]);
$shared_files = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CloudStore - Shared Files</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div class="header">
        <div class="logo">
            <i class="fas fa-cloud"></i>
            <span>CloudStore</span>
        </div>

        <nav>
            <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="share.php" class="active">Shared Files</a></li>
                <?php if (isAdmin()): ?>
                    <li><a href="admin_panel.php">Admin Panel</a></li>
                <?php endif; ?>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>

        <div class="user-info">
            <div class="user-avatar"><?= strtoupper(substr($_SESSION['username'], 0, 1)) ?></div>
            <span><?= htmlspecialchars($_SESSION['username']) ?></span>
        </div>
    </div>

    <div class="main-content">
        <div class="card">
            <h2>My Shared Files</h2>
            <p style="color: #6b7280; margin-bottom: 2rem;">
                Files you've shared with others. Anyone with the link can download these files.
            </p>

            <?php if (empty($shared_files)): ?>
                <div style="text-align: center; padding: 3rem; color: #6b7280;">
                    <i class="fas fa-share-alt" style="font-size: 3rem; margin-bottom: 1rem; opacity: 0.5;"></i>
                    <h3>No shared files yet</h3>
                    <p>Go to your dashboard and share some files to see them here!</p>
                    <a href="dashboard.php" class="btn btn-primary">
                        <i class="fas fa-arrow-left"></i> Back to Dashboard
                    </a>
                </div>
            <?php else: ?>
                <div class="file-list">
                    <?php foreach ($shared_files as $file): ?>
                        <div class="file-item">
                            <div class="file-icon"><?= getFileIcon($file['file_extension']) ?></div>
                            <div class="file-info">
                                <h4><?= htmlspecialchars($file['original_name']) ?></h4>
                                <div class="file-meta">
                                    Shared <?= date('M j, Y', strtotime($file['shared_at'])) ?> • 
                                    <?= $file['download_count'] ?> downloads
                                </div>
                            </div>
                            <div class="file-size"><?= formatFileSize($file['file_size']) ?></div>
                            <div class="file-date"><?= date('M j, Y', strtotime($file['shared_at'])) ?></div>
                            <div class="file-actions-menu">
                                <button onclick="copyShareLink('<?= $file['share_token'] ?>')" title="Copy Link">
                                    <i class="fas fa-copy"></i>
                                </button>
                                <button onclick="viewShareStats(<?= $file['id'] ?>)" title="View Stats">
                                    <i class="fas fa-chart-bar"></i>
                                </button>
                                <button onclick="removeShare(<?= $file['id'] ?>, '<?= htmlspecialchars($file['original_name']) ?>')" title="Stop Sharing">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        function copyShareLink(token) {
            const shareUrl = window.location.origin + window.location.pathname + '?token=' + token;
            navigator.clipboard.writeText(shareUrl).then(() => {
                alert('Share link copied to clipboard!');
            }).catch(err => {
                // Fallback for older browsers
                const textArea = document.createElement('textarea');
                textArea.value = shareUrl;
                document.body.appendChild(textArea);
                textArea.select();
                document.execCommand('copy');
                document.body.removeChild(textArea);
                alert('Share link copied to clipboard!');
            });
        }

        function removeShare(fileId, fileName) {
            if (confirm('Stop sharing "' + fileName + '"? This will disable the share link.')) {
                // Implementation would go here
                alert('Feature coming soon!');
            }
        }

        function viewShareStats(fileId) {
            alert('Share statistics feature coming soon!');
        }
    </script>
</body>
</html>