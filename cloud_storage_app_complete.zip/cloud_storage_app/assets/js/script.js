// Cloud Storage App - Main JavaScript

// Modal functions
function openUploadModal() {
    document.getElementById('uploadModal').style.display = 'block';
}

function openFolderModal() {
    document.getElementById('folderModal').style.display = 'block';
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

// Close modals when clicking outside
window.onclick = function(event) {
    const modals = document.getElementsByClassName('modal');
    for (let i = 0; i < modals.length; i++) {
        if (event.target === modals[i]) {
            modals[i].style.display = 'none';
        }
    }
}

// Drag and drop functionality
const dropZone = document.getElementById('dropZone');

dropZone.addEventListener('dragover', function(e) {
    e.preventDefault();
    dropZone.classList.add('dragover');
});

dropZone.addEventListener('dragleave', function(e) {
    e.preventDefault();
    dropZone.classList.remove('dragover');
});

dropZone.addEventListener('drop', function(e) {
    e.preventDefault();
    dropZone.classList.remove('dragover');

    const files = e.dataTransfer.files;
    if (files.length > 0) {
        uploadFiles(files);
    }
});

// Click to upload
dropZone.addEventListener('click', function() {
    openUploadModal();
});

// File upload handling
document.getElementById('uploadForm').addEventListener('submit', function(e) {
    e.preventDefault();

    const fileInput = document.getElementById('files');
    if (fileInput.files.length > 0) {
        uploadFiles(fileInput.files);
    }
});

function uploadFiles(files) {
    const formData = new FormData();

    // Add folder_id if we're in a folder
    if (window.currentFolder) {
        formData.append('folder_id', window.currentFolder);
    }

    // Add all files
    for (let i = 0; i < files.length; i++) {
        formData.append('files[]', files[i]);
    }

    // Show progress
    const progressDiv = document.getElementById('uploadProgress');
    const progressBar = document.getElementById('progressBar');
    const progressText = document.getElementById('progressText');

    progressDiv.style.display = 'block';

    const xhr = new XMLHttpRequest();

    xhr.upload.addEventListener('progress', function(e) {
        if (e.lengthComputable) {
            const percentComplete = (e.loaded / e.total) * 100;
            progressBar.style.width = percentComplete + '%';
            progressText.textContent = Math.round(percentComplete) + '%';
        }
    });

    xhr.addEventListener('load', function() {
        if (xhr.status === 200) {
            const response = JSON.parse(xhr.responseText);
            if (response.success) {
                location.reload();
            } else {
                alert('Upload failed: ' + response.message);
                progressDiv.style.display = 'none';
            }
        } else {
            alert('Upload failed. Please try again.');
            progressDiv.style.display = 'none';
        }
    });

    xhr.addEventListener('error', function() {
        alert('Upload failed. Please check your connection.');
        progressDiv.style.display = 'none';
    });

    xhr.open('POST', 'upload.php');
    xhr.send(formData);

    closeModal('uploadModal');
}

// Folder creation
document.getElementById('folderForm').addEventListener('submit', function(e) {
    e.preventDefault();

    const formData = new FormData(this);

    fetch('folder_operations.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            location.reload();
        } else {
            alert('Failed to create folder: ' + data.message);
        }
    })
    .catch(error => {
        alert('An error occurred. Please try again.');
    });

    closeModal('folderModal');
});

// File operations
function downloadFile(fileId) {
    window.open('download.php?id=' + fileId, '_blank');
}

function previewFile(fileId) {
    fetch('download.php?id=' + fileId + '&preview=1')
        .then(response => response.blob())
        .then(blob => {
            const url = URL.createObjectURL(blob);
            const modal = document.getElementById('previewModal');
            const content = document.getElementById('previewContent');
            const title = document.getElementById('previewTitle');

            // Get file info for title
            fetch('download.php?id=' + fileId + '&info=1')
                .then(response => response.json())
                .then(info => {
                    title.textContent = info.name;

                    if (info.mime_type.startsWith('image/')) {
                        content.innerHTML = `<img src="${url}" alt="${info.name}" style="max-width: 100%; height: auto;">`;
                    } else if (info.mime_type.startsWith('video/')) {
                        content.innerHTML = `<video controls style="max-width: 100%; height: auto;">
                            <source src="${url}" type="${info.mime_type}">
                            Your browser does not support video playback.
                        </video>`;
                    } else if (info.mime_type === 'application/pdf') {
                        content.innerHTML = `<embed src="${url}" type="application/pdf" style="width: 100%; height: 600px;">`;
                    } else {
                        content.innerHTML = `<p>Preview not available for this file type.</p>
                            <a href="${url}" download="${info.name}" class="btn btn-primary">
                                <i class="fas fa-download"></i> Download
                            </a>`;
                    }

                    modal.style.display = 'block';
                });
        })
        .catch(error => {
            alert('Failed to load preview.');
        });
}

function shareFile(fileId, fileName) {
    if (confirm('Generate a sharing link for "' + fileName + '"?')) {
        fetch('share.php?action=create&file_id=' + fileId)
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const shareUrl = window.location.origin + window.location.pathname.replace('dashboard.php', '') + 'share.php?token=' + data.token;

                    // Create a modal to show the share link
                    const shareModal = document.createElement('div');
                    shareModal.className = 'modal';
                    shareModal.style.display = 'block';
                    shareModal.innerHTML = `
                        <div class="modal-content">
                            <div class="modal-header">
                                <h2>Share File</h2>
                                <span class="close" onclick="this.closest('.modal').remove()">&times;</span>
                            </div>
                            <div class="form-group">
                                <label>Share Link:</label>
                                <input type="text" class="form-control" value="${shareUrl}" readonly onclick="this.select()">
                            </div>
                            <p style="color: #6b7280; font-size: 0.875rem;">
                                Anyone with this link can download the file. Copy the link to share it.
                            </p>
                            <button class="btn btn-primary" onclick="navigator.clipboard.writeText('${shareUrl}').then(() => alert('Link copied to clipboard!'))">
                                <i class="fas fa-copy"></i> Copy Link
                            </button>
                        </div>
                    `;
                    document.body.appendChild(shareModal);
                } else {
                    alert('Failed to create share link: ' + data.message);
                }
            })
            .catch(error => {
                alert('Failed to create share link.');
            });
    }
}

function deleteFile(fileId, fileName) {
    if (confirm('Are you sure you want to delete "' + fileName + '"?')) {
        fetch('folder_operations.php?action=delete_file&id=' + fileId, {
            method: 'POST'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert('Failed to delete file: ' + data.message);
            }
        })
        .catch(error => {
            alert('Failed to delete file.');
        });
    }
}

function deleteFolder(folderId, folderName) {
    if (confirm('Are you sure you want to delete the folder "' + folderName + '" and all its contents?')) {
        fetch('folder_operations.php?action=delete_folder&id=' + folderId, {
            method: 'POST'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert('Failed to delete folder: ' + data.message);
            }
        })
        .catch(error => {
            alert('Failed to delete folder.');
        });
    }
}

function renameFolder(folderId, currentName) {
    const newName = prompt('Enter new folder name:', currentName);
    if (newName && newName !== currentName) {
        const formData = new FormData();
        formData.append('action', 'rename_folder');
        formData.append('id', folderId);
        formData.append('new_name', newName);

        fetch('folder_operations.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert('Failed to rename folder: ' + data.message);
            }
        })
        .catch(error => {
            alert('Failed to rename folder.');
        });
    }
}

// Auto-hide alerts after 5 seconds
document.addEventListener('DOMContentLoaded', function() {
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(function(alert) {
        setTimeout(function() {
            alert.style.opacity = '0';
            setTimeout(function() {
                alert.remove();
            }, 300);
        }, 5000);
    });
});