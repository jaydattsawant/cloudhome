<?php
require_once 'database.php';

// Check if user is logged in
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// Check if user is admin
function isAdmin() {
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
}

// Redirect if not logged in
function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: login.php');
        exit();
    }
}

// Redirect if not admin
function requireAdmin() {
    requireLogin();
    if (!isAdmin()) {
        header('Location: dashboard.php?error=access_denied');
        exit();
    }
}

// Sanitize input
function sanitizeInput($input) {
    return htmlspecialchars(strip_tags(trim($input)));
}

// Format file size
function formatFileSize($size) {
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $power = $size > 0 ? floor(log($size, 1024)) : 0;
    return number_format($size / pow(1024, $power), 2) . ' ' . $units[$power];
}

// Generate secure token
function generateToken($length = 32) {
    return bin2hex(random_bytes($length / 2));
}

// Log user activity
function logActivity($user_id, $action, $file_name = null) {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, action, file_name, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$user_id, $action, $file_name, $_SERVER['REMOTE_ADDR'], $_SERVER['HTTP_USER_AGENT']]);
}

// Get user storage info
function getUserStorageInfo($user_id) {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("SELECT storage_limit, storage_used FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

// Update user storage
function updateUserStorage($user_id) {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("UPDATE users SET storage_used = (SELECT COALESCE(SUM(file_size), 0) FROM files WHERE user_id = ?) WHERE id = ?");
    $stmt->execute([$user_id, $user_id]);
}

// Get folder breadcrumb
function getFolderBreadcrumb($folder_id) {
    if (!$folder_id) return [];

    $pdo = getDBConnection();
    $breadcrumb = [];

    while ($folder_id) {
        $stmt = $pdo->prepare("SELECT id, name, parent_id FROM folders WHERE id = ?");
        $stmt->execute([$folder_id]);
        $folder = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($folder) {
            array_unshift($breadcrumb, $folder);
            $folder_id = $folder['parent_id'];
        } else {
            break;
        }
    }

    return $breadcrumb;
}

// Check if file type can be previewed
function canPreviewFile($extension) {
    $previewable = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'mp4', 'webm', 'ogg', 'mp3', 'wav', 'pdf'];
    return in_array(strtolower($extension), $previewable);
}

// Get file icon based on extension
function getFileIcon($extension) {
    $icons = [
        'pdf' => '📄', 'doc' => '📄', 'docx' => '📄', 'txt' => '📄',
        'jpg' => '🖼️', 'jpeg' => '🖼️', 'png' => '🖼️', 'gif' => '🖼️',
        'mp4' => '🎥', 'avi' => '🎥', 'mov' => '🎥', 'wmv' => '🎥',
        'mp3' => '🎵', 'wav' => '🎵', 'flac' => '🎵',
        'zip' => '📦', 'rar' => '📦', '7z' => '📦',
        'xlsx' => '📊', 'xls' => '📊', 'csv' => '📊',
        'pptx' => '📋', 'ppt' => '📋'
    ];

    return isset($icons[strtolower($extension)]) ? $icons[strtolower($extension)] : '📁';
}
?>