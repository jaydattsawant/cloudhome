<?php
require_once 'config/functions.php';
requireLogin();

$current_folder = isset($_GET['folder']) ? (int)$_GET['folder'] : null;
$user_id = $_SESSION['user_id'];

$pdo = getDBConnection();

// Get user storage info
$storage = getUserStorageInfo($user_id);

// Get breadcrumb navigation
$breadcrumb = getFolderBreadcrumb($current_folder);

// Get folders in current directory
$folder_stmt = $pdo->prepare("SELECT * FROM folders WHERE user_id = ? AND parent_id " . 
                             ($current_folder ? "= ?" : "IS NULL") . " ORDER BY name ASC");
if ($current_folder) {
    $folder_stmt->execute([$user_id, $current_folder]);
} else {
    $folder_stmt->execute([$user_id]);
}
$folders = $folder_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get files in current directory
$file_stmt = $pdo->prepare("SELECT * FROM files WHERE user_id = ? AND folder_id " . 
                          ($current_folder ? "= ?" : "IS NULL") . " ORDER BY upload_date DESC");
if ($current_folder) {
    $file_stmt->execute([$user_id, $current_folder]);
} else {
    $file_stmt->execute([$user_id]);
}
$files = $file_stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate storage percentage
$storage_percent = $storage['storage_limit'] > 0 ? ($storage['storage_used'] / $storage['storage_limit']) * 100 : 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CloudStore - Dashboard</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div class="header">
        <div class="logo">
            <i class="fas fa-cloud"></i>
            <span>CloudStore</span>
        </div>

        <nav>
            <ul class="nav-menu">
                <li><a href="dashboard.php" class="active">Dashboard</a></li>
                <?php if (isAdmin()): ?>
                    <li><a href="admin_panel.php">Admin Panel</a></li>
                <?php endif; ?>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>

        <div class="user-info">
            <div class="user-avatar"><?= strtoupper(substr($_SESSION['username'], 0, 1)) ?></div>
            <span><?= htmlspecialchars($_SESSION['username']) ?></span>
            <?php if (isAdmin()): ?>
                <span class="badge" style="background: #ef4444; color: white; padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.75rem;">ADMIN</span>
            <?php endif; ?>
        </div>
    </div>

    <div class="main-content">
        <?php if (isset($_GET['success'])): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> 
                <?php 
                switch($_GET['success']) {
                    case 'upload': echo 'File uploaded successfully!'; break;
                    case 'folder': echo 'Folder created successfully!'; break;
                    case 'delete': echo 'Item deleted successfully!'; break;
                    case 'share': echo 'File shared successfully!'; break;
                    default: echo 'Operation completed successfully!';
                }
                ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_GET['error'])): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i> 
                <?php 
                switch($_GET['error']) {
                    case 'upload': echo 'Upload failed. Please try again.'; break;
                    case 'storage': echo 'Not enough storage space available.'; break;
                    case 'access_denied': echo 'Access denied.'; break;
                    default: echo 'An error occurred. Please try again.';
                }
                ?>
            </div>
        <?php endif; ?>

        <div class="dashboard-grid">
            <!-- Storage Info -->
            <div class="card storage-info">
                <h2>Storage Usage</h2>
                <div class="storage-circle">
                    <svg width="120" height="120" viewBox="0 0 120 120">
                        <circle cx="60" cy="60" r="50" fill="none" stroke="#e5e7eb" stroke-width="8"/>
                        <circle cx="60" cy="60" r="50" fill="none" stroke="#4f46e5" stroke-width="8"
                                stroke-dasharray="<?= 2 * pi() * 50 ?>" 
                                stroke-dashoffset="<?= 2 * pi() * 50 * (1 - $storage_percent / 100) ?>"
                                stroke-linecap="round"/>
                    </svg>
                    <div class="storage-text">
                        <?= number_format($storage_percent, 1) ?>%<br>
                        <small>Used</small>
                    </div>
                </div>

                <div class="storage-details">
                    <div class="storage-item">
                        <div class="stat-number"><?= formatFileSize($storage['storage_used']) ?></div>
                        <div class="stat-label">Used</div>
                    </div>
                    <div class="storage-item">
                        <div class="stat-number"><?= formatFileSize($storage['storage_limit'] - $storage['storage_used']) ?></div>
                        <div class="stat-label">Available</div>
                    </div>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="card">
                <h2>Quick Actions</h2>
                <div class="file-actions">
                    <button class="btn btn-primary" onclick="openUploadModal()">
                        <i class="fas fa-upload"></i> Upload Files
                    </button>
                    <button class="btn btn-secondary" onclick="openFolderModal()">
                        <i class="fas fa-folder-plus"></i> New Folder
                    </button>
                    <a href="share.php" class="btn btn-success">
                        <i class="fas fa-share-alt"></i> Shared Files
                    </a>
                </div>

                <!-- Upload Progress -->
                <div id="uploadProgress" style="display: none;">
                    <h3>Upload Progress</h3>
                    <div class="progress">
                        <div class="progress-bar" id="progressBar" style="width: 0%">
                            <span class="progress-text" id="progressText">0%</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Navigation Breadcrumb -->
        <?php if (!empty($breadcrumb) || $current_folder): ?>
            <div class="breadcrumb">
                <a href="dashboard.php"><i class="fas fa-home"></i> Home</a>
                <?php foreach ($breadcrumb as $crumb): ?>
                    <i class="fas fa-chevron-right"></i>
                    <a href="dashboard.php?folder=<?= $crumb['id'] ?>"><?= htmlspecialchars($crumb['name']) ?></a>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <!-- File Manager -->
        <div class="card">
            <h2>
                <?php if ($current_folder): ?>
                    <?php 
                    $current_folder_name = end($breadcrumb)['name'] ?? 'Folder';
                    echo htmlspecialchars($current_folder_name);
                    ?>
                <?php else: ?>
                    My Files
                <?php endif; ?>
                <span style="color: #6b7280; font-weight: normal; font-size: 0.9rem;">
                    (<?= count($folders) + count($files) ?> items)
                </span>
            </h2>

            <!-- Drop Zone -->
            <div class="upload-area" id="dropZone">
                <div class="upload-icon">
                    <i class="fas fa-cloud-upload-alt"></i>
                </div>
                <h3>Drag & Drop Files Here</h3>
                <p>Or click the Upload button above</p>
            </div>

            <!-- File List -->
            <div class="file-list">
                <?php if (empty($folders) && empty($files)): ?>
                    <div style="text-align: center; padding: 3rem; color: #6b7280;">
                        <i class="fas fa-folder-open" style="font-size: 3rem; margin-bottom: 1rem; opacity: 0.5;"></i>
                        <h3>No files or folders yet</h3>
                        <p>Upload your first file or create a folder to get started!</p>
                    </div>
                <?php endif; ?>

                <!-- Folders -->
                <?php foreach ($folders as $folder): ?>
                    <div class="file-item">
                        <div class="file-icon">📁</div>
                        <div class="file-info">
                            <h4>
                                <a href="dashboard.php?folder=<?= $folder['id'] ?>" style="text-decoration: none; color: #4f46e5;">
                                    <?= htmlspecialchars($folder['name']) ?>
                                </a>
                            </h4>
                            <div class="file-meta">Folder • Created <?= date('M j, Y', strtotime($folder['created_at'])) ?></div>
                        </div>
                        <div class="file-size">-</div>
                        <div class="file-date"><?= date('M j, Y', strtotime($folder['created_at'])) ?></div>
                        <div class="file-actions-menu">
                            <button onclick="renameFolder(<?= $folder['id'] ?>, '<?= htmlspecialchars($folder['name']) ?>')" title="Rename">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button onclick="deleteFolder(<?= $folder['id'] ?>, '<?= htmlspecialchars($folder['name']) ?>')" title="Delete">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                <?php endforeach; ?>

                <!-- Files -->
                <?php foreach ($files as $file): ?>
                    <div class="file-item">
                        <div class="file-icon"><?= getFileIcon($file['file_extension']) ?></div>
                        <div class="file-info">
                            <h4><?= htmlspecialchars($file['original_name']) ?></h4>
                            <div class="file-meta">
                                <?= strtoupper($file['file_extension']) ?> • 
                                <?= $file['downloads'] ?> downloads
                            </div>
                        </div>
                        <div class="file-size"><?= formatFileSize($file['file_size']) ?></div>
                        <div class="file-date"><?= date('M j, Y', strtotime($file['upload_date'])) ?></div>
                        <div class="file-actions-menu">
                            <?php if (canPreviewFile($file['file_extension'])): ?>
                                <button onclick="previewFile(<?= $file['id'] ?>)" title="Preview">
                                    <i class="fas fa-eye"></i>
                                </button>
                            <?php endif; ?>
                            <button onclick="downloadFile(<?= $file['id'] ?>)" title="Download">
                                <i class="fas fa-download"></i>
                            </button>
                            <button onclick="shareFile(<?= $file['id'] ?>, '<?= htmlspecialchars($file['original_name']) ?>')" title="Share">
                                <i class="fas fa-share-alt"></i>
                            </button>
                            <button onclick="deleteFile(<?= $file['id'] ?>, '<?= htmlspecialchars($file['original_name']) ?>')" title="Delete">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- Upload Modal -->
    <div id="uploadModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Upload Files</h2>
                <span class="close" onclick="closeModal('uploadModal')">&times;</span>
            </div>
            <form id="uploadForm" enctype="multipart/form-data">
                <input type="hidden" name="folder_id" value="<?= $current_folder ?>">
                <div class="form-group">
                    <label for="files">Select Files</label>
                    <input type="file" id="files" name="files[]" class="form-control" multiple>
                    <small style="color: #6b7280;">You can select multiple files at once</small>
                </div>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-upload"></i> Upload
                </button>
            </form>
        </div>
    </div>

    <!-- New Folder Modal -->
    <div id="folderModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Create New Folder</h2>
                <span class="close" onclick="closeModal('folderModal')">&times;</span>
            </div>
            <form id="folderForm">
                <input type="hidden" name="parent_id" value="<?= $current_folder ?>">
                <div class="form-group">
                    <label for="folder_name">Folder Name</label>
                    <input type="text" id="folder_name" name="folder_name" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-folder-plus"></i> Create Folder
                </button>
            </form>
        </div>
    </div>

    <!-- File Preview Modal -->
    <div id="previewModal" class="modal">
        <div class="modal-content" style="max-width: 90%; max-height: 90%;">
            <div class="modal-header">
                <h2 id="previewTitle">File Preview</h2>
                <span class="close" onclick="closeModal('previewModal')">&times;</span>
            </div>
            <div id="previewContent" class="file-preview">
                <!-- Preview content will be loaded here -->
            </div>
        </div>
    </div>

    <script src="assets/js/script.js"></script>
    <script>
        // Set current folder for JavaScript
        window.currentFolder = <?= json_encode($current_folder) ?>;
    </script>
</body>
</html>