<?php
require_once 'config/functions.php';
requireLogin();

header('Content-Type: application/json');

$user_id = $_SESSION['user_id'];
$action = $_POST['action'] ?? $_GET['action'] ?? '';

$pdo = getDBConnection();

switch ($action) {
    case 'create':
    case '': // Default action is create
        $folder_name = sanitizeInput($_POST['folder_name'] ?? '');
        $parent_id = isset($_POST['parent_id']) ? (int)$_POST['parent_id'] : null;

        if (empty($folder_name)) {
            echo json_encode(['success' => false, 'message' => 'Folder name is required']);
            exit;
        }

        if (strlen($folder_name) > 255) {
            echo json_encode(['success' => false, 'message' => 'Folder name is too long']);
            exit;
        }

        // Validate parent folder if specified
        if ($parent_id) {
            $stmt = $pdo->prepare("SELECT id, path FROM folders WHERE id = ? AND user_id = ?");
            $stmt->execute([$parent_id, $user_id]);
            $parent = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$parent) {
                echo json_encode(['success' => false, 'message' => 'Invalid parent folder']);
                exit;
            }
            $path = $parent['path'] . '/' . $folder_name;
        } else {
            $path = $folder_name;
        }

        // Check if folder name already exists in the same location
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM folders WHERE user_id = ? AND parent_id " . 
                             ($parent_id ? "= ?" : "IS NULL") . " AND name = ?");

        if ($parent_id) {
            $stmt->execute([$user_id, $parent_id, $folder_name]);
        } else {
            $stmt->execute([$user_id, $folder_name]);
        }

        if ($stmt->fetchColumn() > 0) {
            echo json_encode(['success' => false, 'message' => 'A folder with this name already exists']);
            exit;
        }

        // Create the folder
        try {
            $stmt = $pdo->prepare("INSERT INTO folders (user_id, parent_id, name, path) VALUES (?, ?, ?, ?)");
            $stmt->execute([$user_id, $parent_id, $folder_name, $path]);

            logActivity($user_id, 'create_folder', $folder_name);

            echo json_encode(['success' => true, 'message' => 'Folder created successfully']);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Failed to create folder']);
        }
        break;

    case 'delete_folder':
        $folder_id = (int)($_POST['id'] ?? $_GET['id'] ?? 0);

        if (!$folder_id) {
            echo json_encode(['success' => false, 'message' => 'Folder ID required']);
            exit;
        }

        // Verify ownership
        $stmt = $pdo->prepare("SELECT name FROM folders WHERE id = ? AND user_id = ?");
        $stmt->execute([$folder_id, $user_id]);
        $folder = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$folder) {
            echo json_encode(['success' => false, 'message' => 'Folder not found or access denied']);
            exit;
        }

        try {
            // Delete all files in folder and subfolders
            $stmt = $pdo->prepare("
                SELECT f.stored_name, f.user_id, f.original_name 
                FROM files f
                JOIN folders fo ON f.folder_id = fo.id OR f.folder_id IN (
                    SELECT id FROM folders WHERE path LIKE CONCAT((SELECT path FROM folders WHERE id = ?), '/%')
                )
                WHERE fo.id = ? OR fo.path LIKE CONCAT((SELECT path FROM folders WHERE id = ?), '/%')
            ");
            $stmt->execute([$folder_id, $folder_id, $folder_id]);
            $files_to_delete = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Delete physical files
            foreach ($files_to_delete as $file) {
                $file_path = UPLOAD_DIR . $file['user_id'] . '/' . $file['stored_name'];
                if (file_exists($file_path)) {
                    unlink($file_path);
                }
            }

            // Delete folder and its contents (CASCADE will handle related records)
            $stmt = $pdo->prepare("DELETE FROM folders WHERE id = ? AND user_id = ?");
            $stmt->execute([$folder_id, $user_id]);

            // Update storage usage
            updateUserStorage($user_id);

            logActivity($user_id, 'delete_folder', $folder['name']);

            echo json_encode(['success' => true, 'message' => 'Folder deleted successfully']);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Failed to delete folder']);
        }
        break;

    case 'delete_file':
        $file_id = (int)($_POST['id'] ?? $_GET['id'] ?? 0);

        if (!$file_id) {
            echo json_encode(['success' => false, 'message' => 'File ID required']);
            exit;
        }

        // Verify ownership
        $stmt = $pdo->prepare("SELECT stored_name, original_name FROM files WHERE id = ? AND user_id = ?");
        $stmt->execute([$file_id, $user_id]);
        $file = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$file) {
            echo json_encode(['success' => false, 'message' => 'File not found or access denied']);
            exit;
        }

        try {
            // Delete physical file
            $file_path = UPLOAD_DIR . $user_id . '/' . $file['stored_name'];
            if (file_exists($file_path)) {
                unlink($file_path);
            }

            // Delete file record
            $stmt = $pdo->prepare("DELETE FROM files WHERE id = ? AND user_id = ?");
            $stmt->execute([$file_id, $user_id]);

            // Update storage usage
            updateUserStorage($user_id);

            logActivity($user_id, 'delete', $file['original_name']);

            echo json_encode(['success' => true, 'message' => 'File deleted successfully']);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Failed to delete file']);
        }
        break;

    case 'rename_folder':
        $folder_id = (int)($_POST['id'] ?? 0);
        $new_name = sanitizeInput($_POST['new_name'] ?? '');

        if (!$folder_id || empty($new_name)) {
            echo json_encode(['success' => false, 'message' => 'Folder ID and new name are required']);
            exit;
        }

        // Verify ownership and get current folder info
        $stmt = $pdo->prepare("SELECT name, parent_id, path FROM folders WHERE id = ? AND user_id = ?");
        $stmt->execute([$folder_id, $user_id]);
        $folder = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$folder) {
            echo json_encode(['success' => false, 'message' => 'Folder not found or access denied']);
            exit;
        }

        // Check if new name already exists in the same location
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM folders WHERE user_id = ? AND parent_id " . 
                             ($folder['parent_id'] ? "= ?" : "IS NULL") . " AND name = ? AND id != ?");

        if ($folder['parent_id']) {
            $stmt->execute([$user_id, $folder['parent_id'], $new_name, $folder_id]);
        } else {
            $stmt->execute([$user_id, $new_name, $folder_id]);
        }

        if ($stmt->fetchColumn() > 0) {
            echo json_encode(['success' => false, 'message' => 'A folder with this name already exists']);
            exit;
        }

        try {
            // Update folder name and path
            $old_path = $folder['path'];
            $new_path = dirname($old_path) === '.' ? $new_name : dirname($old_path) . '/' . $new_name;

            $stmt = $pdo->prepare("UPDATE folders SET name = ?, path = ? WHERE id = ?");
            $stmt->execute([$new_name, $new_path, $folder_id]);

            // Update paths of all subfolders
            $stmt = $pdo->prepare("UPDATE folders SET path = REPLACE(path, ?, ?) WHERE path LIKE ?");
            $stmt->execute([$old_path, $new_path, $old_path . '/%']);

            logActivity($user_id, 'rename_folder', $folder['name'] . ' -> ' . $new_name);

            echo json_encode(['success' => true, 'message' => 'Folder renamed successfully']);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Failed to rename folder']);
        }
        break;

    default:
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
        break;
}
?>