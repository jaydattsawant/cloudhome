<?php
require_once 'config/functions.php';
requireLogin();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$user_id = $_SESSION['user_id'];
$folder_id = isset($_POST['folder_id']) ? (int)$_POST['folder_id'] : null;

// Validate folder ownership if folder_id is provided
if ($folder_id) {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("SELECT id FROM folders WHERE id = ? AND user_id = ?");
    $stmt->execute([$folder_id, $user_id]);
    if (!$stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Invalid folder']);
        exit;
    }
}

if (!isset($_FILES['files']) || !is_array($_FILES['files']['name'])) {
    echo json_encode(['success' => false, 'message' => 'No files selected']);
    exit;
}

$pdo = getDBConnection();
$storage = getUserStorageInfo($user_id);
$uploaded_files = [];
$errors = [];

// Calculate total size of files to upload
$total_upload_size = 0;
for ($i = 0; $i < count($_FILES['files']['name']); $i++) {
    if ($_FILES['files']['error'][$i] === UPLOAD_ERR_OK) {
        $total_upload_size += $_FILES['files']['size'][$i];
    }
}

// Check storage limit
if ($storage['storage_used'] + $total_upload_size > $storage['storage_limit']) {
    echo json_encode([
        'success' => false, 
        'message' => 'Not enough storage space. Need ' . formatFileSize($total_upload_size) . 
                     ' but only have ' . formatFileSize($storage['storage_limit'] - $storage['storage_used']) . ' available.'
    ]);
    exit;
}

// Process each file
for ($i = 0; $i < count($_FILES['files']['name']); $i++) {
    $file = [
        'name' => $_FILES['files']['name'][$i],
        'tmp_name' => $_FILES['files']['tmp_name'][$i],
        'size' => $_FILES['files']['size'][$i],
        'error' => $_FILES['files']['error'][$i],
        'type' => $_FILES['files']['type'][$i]
    ];

    if ($file['error'] !== UPLOAD_ERR_OK) {
        $errors[] = "Error uploading {$file['name']}: Upload error code {$file['error']}";
        continue;
    }

    if ($file['size'] <= 0) {
        $errors[] = "Error uploading {$file['name']}: File is empty";
        continue;
    }

    // Get file extension and validate
    $file_extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

    // Generate unique filename
    $stored_name = uniqid() . '_' . time() . '.' . $file_extension;

    // Create user directory if it doesn't exist
    $user_dir = UPLOAD_DIR . $user_id . '/';
    if (!file_exists($user_dir)) {
        mkdir($user_dir, 0777, true);
    }

    // Move uploaded file
    $file_path = $user_dir . $stored_name;
    if (move_uploaded_file($file['tmp_name'], $file_path)) {
        // Get MIME type
        $mime_type = mime_content_type($file_path);

        // Insert file record into database
        try {
            $stmt = $pdo->prepare("
                INSERT INTO files (user_id, folder_id, original_name, stored_name, file_size, mime_type, file_extension) 
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");

            $stmt->execute([
                $user_id,
                $folder_id,
                $file['name'],
                $stored_name,
                $file['size'],
                $mime_type,
                $file_extension
            ]);

            $uploaded_files[] = [
                'id' => $pdo->lastInsertId(),
                'name' => $file['name'],
                'size' => $file['size']
            ];

            // Log activity
            logActivity($user_id, 'upload', $file['name']);

        } catch (PDOException $e) {
            $errors[] = "Database error for {$file['name']}: " . $e->getMessage();
            // Remove the uploaded file if database insert failed
            unlink($file_path);
        }
    } else {
        $errors[] = "Failed to save {$file['name']}";
    }
}

// Update user storage
updateUserStorage($user_id);

if (!empty($uploaded_files)) {
    $message = count($uploaded_files) . ' file(s) uploaded successfully';
    if (!empty($errors)) {
        $message .= '. Some files failed: ' . implode(', ', $errors);
    }

    echo json_encode([
        'success' => true,
        'message' => $message,
        'files' => $uploaded_files,
        'errors' => $errors
    ]);
} else {
    echo json_encode([
        'success' => false,
        'message' => 'No files were uploaded. Errors: ' . implode(', ', $errors)
    ]);
}
?>