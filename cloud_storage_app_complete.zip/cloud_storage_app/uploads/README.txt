# Uploads Directory

This directory stores all uploaded files from users.

Structure:
- Each user gets their own subdirectory (by user ID)
- Files are stored with unique names to prevent conflicts
- Original filenames are stored in the database

Example:
uploads/
  1/  (Admin user files)
    abc123_1632147890.pdf
    def456_1632147891.jpg
  2/  (Regular user files)
    ghi789_1632147892.docx

The directory is auto-created when the first file is uploaded.
Make sure this directory has write permissions (777 on Linux/Mac).
