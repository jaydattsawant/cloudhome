# CloudStore - PHP Cloud Storage Application

## INSTALLATION INSTRUCTIONS FOR XAMPP

### Prerequisites
- XAMPP installed with Apache, MySQL, and PHP enabled
- Web browser (Chrome, Firefox, Safari, etc.)

### Step 1: Extract Files
1. Extract the cloud_storage_app folder to your XAMPP htdocs directory
   Usually: C:\xampp\htdocs\cloud_storage_app\ (Windows)
   Or: /Applications/XAMPP/htdocs/cloud_storage_app/ (Mac)

### Step 2: Configure PHP Settings (IMPORTANT)
1. Open XAMPP Control Panel
2. Click "Config" next to Apache
3. Select "PHP (php.ini)"
4. Find and modify these settings:

   upload_max_filesize = 100M
   post_max_size = 100M
   max_execution_time = 300
   max_input_time = 300
   memory_limit = 256M

5. Save the file and restart Apache

### Step 3: Database Setup
1. Start Apache and MySQL from XAMPP Control Panel
2. Open phpMyAdmin in your browser: http://localhost/phpmyadmin
3. Click "Import" tab
4. Choose the "database.sql" file from the project folder
5. Click "Go" to import the database

### Step 4: File Permissions
1. Make sure the "uploads" folder is writable
2. On Windows: Right-click uploads folder → Properties → Security → Give full control
3. On Mac/Linux: chmod 777 uploads/

### Step 5: Access the Application
1. Open your web browser
2. Go to: http://localhost/cloud_storage_app/
3. Login with test accounts:

   ADMIN ACCOUNT:
   - Email: admin@cloudstore.local
   - Password: admin123

   USER ACCOUNT:
   - Email: user@cloudstore.local
   - Password: user123

### Features Overview

#### For Regular Users:
- Upload files of any type and size (within limits)
- Create and manage nested folders
- Preview images and videos
- Share files via public links
- Download files
- View storage usage

#### For Admin Users:
- All user features plus:
- View all users and their files
- Manage user storage limits
- Activate/deactivate user accounts
- Promote users to admin
- View system statistics
- Monitor user activity

### File Structure
- config/database.php - Database connection settings
- config/functions.php - Common PHP functions
- assets/css/style.css - Main stylesheet
- assets/js/script.js - JavaScript functionality
- uploads/ - File storage directory (auto-created)
- users.csv - Sample user data reference

### Database Tables
- users - User accounts and settings
- files - File metadata and storage info
- folders - Nested folder structure
- file_shares - Public sharing links
- activity_logs - User activity tracking

### Security Features
- Password hashing with PHP password_hash()
- Session management
- File type validation
- User access control
- SQL injection protection with prepared statements

### Troubleshooting

#### Problem: Files won't upload
Solution: Check PHP settings in php.ini (Step 2 above)

#### Problem: Database connection error
Solution: Make sure MySQL is running and database is imported

#### Problem: Permission denied errors
Solution: Check folder permissions (Step 4 above)

#### Problem: Large files fail to upload
Solution: Increase PHP limits in php.ini:
- upload_max_filesize
- post_max_size
- memory_limit

### Customization
- To change storage limits: Use admin panel or modify database directly
- To add file types: Update ALLOWED_EXTENSIONS in config/database.php
- To modify design: Edit assets/css/style.css
- To add features: Extend the PHP files as needed

### CSV File Management
The users.csv file contains sample user data for reference. The actual user management is done through:
1. Web registration form
2. Admin panel interface
3. Direct database access via phpMyAdmin

Admin users can:
- View all users in the admin panel
- Modify storage limits
- Change user roles and status
- Export user data if needed

Regular users can:
- Only access their own files
- Cannot see other users' data
- Register for new accounts via web form

### Support
For issues or questions, check:
1. XAMPP Apache/MySQL are running
2. Database imported correctly
3. File permissions set properly
4. PHP configuration matches requirements

This application is designed for local development and testing with XAMPP. For production use, additional security measures should be implemented.

Version: 1.0
Created: September 2025
Compatible with: PHP 7.4+, MySQL 5.7+